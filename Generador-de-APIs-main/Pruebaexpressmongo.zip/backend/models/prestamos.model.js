mongoose=require("mongoose");
        const AutoIncrement = require("mongoose-sequence")(mongoose);

        const  PrestamosSchema=new mongoose.Schema({
id_prestamo:{type:Number,},
fecha_pretamo:{type:String,},
fecha_tope:{type:String,},
fecha_entrega:{type:String,required: true},
cod_cliente:{type:Number,},
n_copia:{type:Number,},
});
        PrestamosSchema.plugin(AutoIncrement,{inc_field:'id_prestamo'});
const Prestamos=mongoose.model('Prestamos',PrestamosSchema);module.exports =Prestamos