mongoose=require("mongoose");
        const AutoIncrement = require("mongoose-sequence")(mongoose);

        const  ClientesSchema=new mongoose.Schema({
cod_cliente:{type:Number,},
dni:{type:Number,},
nombre:{type:String,},
apellido1:{type:String,},
apellido2:{type:String,},
direccion:{type:String,required: true},
email:{type:String,},
});
        ClientesSchema.plugin(AutoIncrement,{inc_field:'cod_cliente'});
const Clientes=mongoose.model('Clientes',ClientesSchema);module.exports =Clientes