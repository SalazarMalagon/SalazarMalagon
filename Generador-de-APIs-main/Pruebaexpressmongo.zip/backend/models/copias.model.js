mongoose=require("mongoose");
        const AutoIncrement = require("mongoose-sequence")(mongoose);

        const  CopiasSchema=new mongoose.Schema({
n_copia:{type:Number,},
deteriorada:{type:Boolean,required: true},
formato:{type:String,},
id_pelicula:{type:Number,},
precio_alquiler:{type:Number,required: true},
});
        CopiasSchema.plugin(AutoIncrement,{inc_field:'n_copia'});
const Copias=mongoose.model('Copias',CopiasSchema);module.exports =Copias