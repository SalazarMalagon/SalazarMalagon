mongoose=require("mongoose");
        const AutoIncrement = require("mongoose-sequence")(mongoose);

        const  PeliculasSchema=new mongoose.Schema({
id_pelicula:{type:Number,},
titulo:{type:String,},
año:{type:Number,required: true},
critica:{type:String,required: true},
caratula:{type:String,required: true},
});
        PeliculasSchema.plugin(AutoIncrement,{inc_field:'id_pelicula'});
const Peliculas=mongoose.model('Peliculas',PeliculasSchema);module.exports =Peliculas