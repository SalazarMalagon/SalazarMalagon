
from typing import List
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from DAO.Connection import BaseDAO
from model.Copias import Copias

class CopiasDAO(BaseDAO):
#CREATE
	def create_Copias(self, copias: Copias):
		try:
			self.db.add(copias)
			self.commit()
			self.db.refresh(copias)
		except IntegrityError:
			self.db.rollback()
			if self.db.query(Copias).filter(Copias.n_copia == copias.n_copia).first():
				raise HTTPException(status_code=400, detail="n_copia already registered")
			return Copias

#READ ALL
	def get_Copias_list(self) -> List[Copias]:
		return self.db.query(Copias).all()

#READ BY PRIMARY_KEY
	def get_Copias(self, n_copia: int) -> Copias:
		return self.db.query(Copias).filter(Copias.n_copia == n_copia).first()

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
	def update_Copias(self, copias: Copias) -> Copias:
		try:
			existing_copias = self.db.query(Copias).filter(Copias.n_copia == copias.n_copia).first()
			if not existing_copias:
				raise HTTPException(status_code=404, detail="Copias no encontrado")
			for key, value in copias.__dict__.items():
				if key != '_sa_instance_state':
					setattr(existing_copias, key, value)
			self.db.commit()
			self.db.refresh(existing_copias)
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al actualizar Copias")
		return existing_copias
#DELETE
	def delete_Copias(self, n_copia: int):
		try:
			data = self.get_Copias(n_copia)
			self.db.delete(data)
			self.commit()
			return True
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al eliminar Copias")

