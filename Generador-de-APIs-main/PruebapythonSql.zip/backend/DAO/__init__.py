from DAO.ClientesDAO import ClientesDAO
from DAO.PrestamosDAO import PrestamosDAO
from DAO.CopiasDAO import CopiasDAO
from DAO.PeliculasDAO import PeliculasDAO
