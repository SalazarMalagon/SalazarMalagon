
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session, Session
from dotenv import load_dotenv
from sqlalchemy.exc import SQLAlchemyError

class Connection:
    __instance = None

    def __new__(cls):
        if cls.__instance is None:
            cls.__instance = super(Connection, cls).__new__(cls)
            try:
                cls.__instance._initialize()
            except Exception as e:
                cls.__instance = None
                raise e
        return cls.__instance

    def _initialize(self):
        load_dotenv()
        db_user = os.getenv('DB_USER')
        print(db_user)
        db_password = os.getenv('DB_PASSWORD')
        db_url = os.getenv('DB_URL')
        db_port = os.getenv('DB_PORT')
        db_name = os.getenv('DB_NAME')

        if not all([db_user, db_password, db_url, db_port, db_name]):
            raise ValueError("Una o más variables de entorno faltan.")

        database_connection = (
            f"mysql+pymysql://{db_user}:{db_password}@{db_url}:{db_port}/{db_name}"
        )

        try:
            self._engine = create_engine(database_connection)
            self._session_factory = sessionmaker(bind=self._engine)
            self._session = scoped_session(self._session_factory)
        except SQLAlchemyError as e:
            raise RuntimeError(f"Error al inicializar la conexión con la base de datos: {e}")

    def get_session(self):
        try:
            return self._session()
        except SQLAlchemyError as e:
            raise RuntimeError(f"Error al obtener la sesión de la base de datos: {e}")

    def close_session(self):
        try:
            self._session.remove()
        except SQLAlchemyError as e:
            raise RuntimeError(f"Error al cerrar la sesión de la base de datos: {e}")
        
class BaseDAO:
    def __init__(self) -> None:
        self.db: Session = Connection().get_session()

    def commit(self):
        self.db.commit()

    def close(self):
        self.db.close()