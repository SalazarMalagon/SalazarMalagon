
from typing import List
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from DAO.Connection import BaseDAO
from model.Prestamos import Prestamos

class PrestamosDAO(BaseDAO):
#CREATE
	def create_Prestamos(self, prestamos: Prestamos):
		try:
			self.db.add(prestamos)
			self.commit()
			self.db.refresh(prestamos)
		except IntegrityError:
			self.db.rollback()
			if self.db.query(Prestamos).filter(Prestamos.id_prestamo == prestamos.id_prestamo).first():
				raise HTTPException(status_code=400, detail="id_prestamo already registered")
			return Prestamos

#READ ALL
	def get_Prestamos_list(self) -> List[Prestamos]:
		return self.db.query(Prestamos).all()

#READ BY PRIMARY_KEY
	def get_Prestamos(self, id_prestamo: int) -> Prestamos:
		return self.db.query(Prestamos).filter(Prestamos.id_prestamo == id_prestamo).first()

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
	def update_Prestamos(self, prestamos: Prestamos) -> Prestamos:
		try:
			existing_prestamos = self.db.query(Prestamos).filter(Prestamos.id_prestamo == prestamos.id_prestamo).first()
			if not existing_prestamos:
				raise HTTPException(status_code=404, detail="Prestamos no encontrado")
			for key, value in prestamos.__dict__.items():
				if key != '_sa_instance_state':
					setattr(existing_prestamos, key, value)
			self.db.commit()
			self.db.refresh(existing_prestamos)
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al actualizar Prestamos")
		return existing_prestamos
#DELETE
	def delete_Prestamos(self, id_prestamo: int):
		try:
			data = self.get_Prestamos(id_prestamo)
			self.db.delete(data)
			self.commit()
			return True
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al eliminar Prestamos")

