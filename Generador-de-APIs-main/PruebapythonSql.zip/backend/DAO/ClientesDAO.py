
from typing import List
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from DAO.Connection import BaseDAO
from model.Clientes import Clientes

class ClientesDAO(BaseDAO):
#CREATE
	def create_Clientes(self, clientes: Clientes):
		try:
			self.db.add(clientes)
			self.commit()
			self.db.refresh(clientes)
		except IntegrityError:
			self.db.rollback()
			if self.db.query(Clientes).filter(Clientes.cod_cliente == clientes.cod_cliente).first():
				raise HTTPException(status_code=400, detail="cod_cliente already registered")
			return Clientes

#READ ALL
	def get_Clientes_list(self) -> List[Clientes]:
		return self.db.query(Clientes).all()

#READ BY PRIMARY_KEY
	def get_Clientes(self, cod_cliente: int) -> Clientes:
		return self.db.query(Clientes).filter(Clientes.cod_cliente == cod_cliente).first()

#READ BY UNIQUE_KEY
	def get_Clientes_dni(self, dni: int) -> Clientes:
		return self.db.query(Clientes).filter(Clientes.dni == dni).first()

	def get_Clientes_email(self, email: str) -> Clientes:
		return self.db.query(Clientes).filter(Clientes.email == email).first()

#UPDATE BY PRIMARY_KEY
	def update_Clientes(self, clientes: Clientes) -> Clientes:
		try:
			existing_clientes = self.db.query(Clientes).filter(Clientes.cod_cliente == clientes.cod_cliente).first()
			if not existing_clientes:
				raise HTTPException(status_code=404, detail="Clientes no encontrado")
			for key, value in clientes.__dict__.items():
				if key != '_sa_instance_state':
					setattr(existing_clientes, key, value)
			self.db.commit()
			self.db.refresh(existing_clientes)
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al actualizar Clientes")
		return existing_clientes
#DELETE
	def delete_Clientes(self, cod_cliente: int):
		try:
			data = self.get_Clientes(cod_cliente)
			self.db.delete(data)
			self.commit()
			return True
		except IntegrityError:
			self.db.rollback()
			raise HTTPException(status_code=400, detail="Error al eliminar Clientes")

