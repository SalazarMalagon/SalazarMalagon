
from sqlalchemy import Column, Integer, String, Boolean, Float, LargeBinary
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Copias(Base):
	__tablename__ = "Copias"
	n_copia= Column(Integer, primary_key=True, autoincrement=True, nullable=False,unique=False)
	deteriorada= Column(Boolean, nullable=True,unique=False)
	formato= Column(String, nullable=False,unique=False)
	id_pelicula= Column(Integer, nullable=False,unique=False)
	precio_alquiler= Column(Integer, nullable=True,unique=False)
