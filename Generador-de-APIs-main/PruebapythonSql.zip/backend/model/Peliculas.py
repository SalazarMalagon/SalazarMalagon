
from sqlalchemy import Column, Integer, String, Boolean, Float, LargeBinary
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Peliculas(Base):
	__tablename__ = "Peliculas"
	id_pelicula= Column(Integer, primary_key=True, autoincrement=True, nullable=False,unique=False)
	titulo= Column(String, nullable=False,unique=False)
	ano= Column(Integer, nullable=True,unique=False)
	critica= Column(String, nullable=True,unique=False)
	caratula= Column(String, nullable=True,unique=False)
