from fastapi import HTTPException
from DAO import PrestamosDAO
from model import Prestamos
from model.Schemas import Prestamos as schema

prestamos_DAO = PrestamosDAO()

#CREATE
def create_Prestamos(data: schema):
	try:
		prestamos = Prestamos(fecha_pretamo=data.fecha_pretamo, fecha_tope=data.fecha_tope, fecha_entrega=data.fecha_entrega, cod_cliente=data.cod_cliente, n_copia=data.n_copia)
		prestamos_DAO.create_Prestamos(prestamos)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#READ ALL
def get_Prestamos():
	return prestamos_DAO.get_Prestamos_list()

#READ BY PRIMARY_KEY
def get_Prestamos_id_prestamo(id_prestamo: int) -> Prestamos:
	return prestamos_DAO.get_Prestamos(id_prestamo)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
def update_Prestamos(data, id_prestamo):
	try:
		prestamos = Prestamos(
			id_prestamo=id_prestamo,
			fecha_pretamo=data.fecha_pretamo,
			fecha_tope=data.fecha_tope,
			fecha_entrega=data.fecha_entrega,
			cod_cliente=data.cod_cliente,
			n_copia=data.n_copia
		)
		prestamos_DAO.update_Prestamos(prestamos)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#DELETE
def delete_Prestamos(data):
	try:
		prestamos_DAO.delete_Prestamos(data)
		return 'Exitoso'
	except Exception as e:
		return 'Error'
