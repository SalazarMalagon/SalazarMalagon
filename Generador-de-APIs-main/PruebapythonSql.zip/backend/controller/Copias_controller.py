from fastapi import HTTPException
from DAO import CopiasDAO
from model import Copias
from model.Schemas import Copias as schema

copias_DAO = CopiasDAO()

#CREATE
def create_Copias(data: schema):
	try:
		copias = Copias(deteriorada=data.deteriorada, formato=data.formato, id_pelicula=data.id_pelicula, precio_alquiler=data.precio_alquiler)
		copias_DAO.create_Copias(copias)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#READ ALL
def get_Copias():
	return copias_DAO.get_Copias_list()

#READ BY PRIMARY_KEY
def get_Copias_n_copia(n_copia: int) -> Copias:
	return copias_DAO.get_Copias(n_copia)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
def update_Copias(data, n_copia):
	try:
		copias = Copias(
			n_copia=n_copia,
			deteriorada=data.deteriorada,
			formato=data.formato,
			id_pelicula=data.id_pelicula,
			precio_alquiler=data.precio_alquiler
		)
		copias_DAO.update_Copias(copias)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#DELETE
def delete_Copias(data):
	try:
		copias_DAO.delete_Copias(data)
		return 'Exitoso'
	except Exception as e:
		return 'Error'
