from fastapi import HTTPException
from DAO import PeliculasDAO
from model import Peliculas
from model.Schemas import Peliculas as schema

peliculas_DAO = PeliculasDAO()

#CREATE
def create_Peliculas(data: schema):
	try:
		peliculas = Peliculas(titulo=data.titulo, año=data.año, critica=data.critica, caratula=data.caratula)
		peliculas_DAO.create_Peliculas(peliculas)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#READ ALL
def get_Peliculas():
	return peliculas_DAO.get_Peliculas_list()

#READ BY PRIMARY_KEY
def get_Peliculas_id_pelicula(id_pelicula: int) -> Peliculas:
	return peliculas_DAO.get_Peliculas(id_pelicula)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
def update_Peliculas(data, id_pelicula):
	try:
		peliculas = Peliculas(
			id_pelicula=id_pelicula,
			titulo=data.titulo,
			año=data.año,
			critica=data.critica,
			caratula=data.caratula
		)
		peliculas_DAO.update_Peliculas(peliculas)
		return 'Exitoso'
	except Exception as e:
		raise HTTPException(status_code=400, detail=f"{e}")

#DELETE
def delete_Peliculas(data):
	try:
		peliculas_DAO.delete_Peliculas(data)
		return 'Exitoso'
	except Exception as e:
		return 'Error'
