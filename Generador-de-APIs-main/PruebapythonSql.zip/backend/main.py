
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from model import Clientes, Prestamos, Copias, Peliculas
from routes.Clientes import Clientes_routes
from routes.Prestamos import Prestamos_routes
from routes.Copias import Copias_routes
from routes.Peliculas import Peliculas_routes

app = FastAPI()

origins = [
    "http://localhost",
    "http://localhost:3000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(Clientes_routes, prefix="/Clientes")
app.include_router(Prestamos_routes, prefix="/Prestamos")
app.include_router(Copias_routes, prefix="/Copias")
app.include_router(Peliculas_routes, prefix="/Peliculas")
