
from fastapi import APIRouter
from model.Schemas import Prestamos
from controller import Prestamos_controller as controller

Prestamos_routes = APIRouter()

#CREATE
@Prestamos_routes.post("/create_Prestamos")
def create_Prestamos(request: Prestamos):
	return controller.create_Prestamos(request)

#READ ALL
@Prestamos_routes.get("/read_Prestamos")
def get_Prestamos_list():
	return controller.get_Prestamos()

#READ ALL BY PRIMARY_KEY
@Prestamos_routes.get("/read_Prestamos/{id_prestamo}")
def get_Prestamos(id_prestamo: int):
	return controller.get_Prestamos_id_prestamo(id_prestamo)

#READ BY UNIQUE_KEY
#UPDATE BY PRIMARY_KEY
@Prestamos_routes.put("/update_Prestamos/{id_prestamo}")
def update_Prestamos(request: Prestamos, id_prestamo: int):
	return controller.update_Prestamos(request, id_prestamo)

#DELETE BY PRIMARY_KEY
@Prestamos_routes.delete("/delete_Prestamos/{id_prestamo}")
def delete_Prestamos(id_prestamo: int):
	return controller.delete_Prestamos(id_prestamo)

