from routes.Clientes import Clientes
from routes.Prestamos import Prestamos
from routes.Copias import Copias
from routes.Peliculas import Peliculas
